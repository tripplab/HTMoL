var http = require('http');
var BinaryServer = require('../../').BinaryServer;
var fs = require('fs');
var express = require('express');
var app = express();
app.use(express.static(__dirname + '/public'));
var server = http.createServer(app);
var bs = BinaryServer({server: server});
console.log("Servidor iniciado.....");
// Start Binary.js server
//var server = BinaryServer({port: 9000});
// Wait for new user connections
bs.on('connection', function(client){
  // Stream a flower as a hello!
  var file = fs.createReadStream('/var/www/html/stream/prueba.xtc');
  var size=file.filesize;
  client.send(file); 
});
server.listen(9000);