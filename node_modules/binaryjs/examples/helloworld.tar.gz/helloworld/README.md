## Hello World example


1. Run the server:
```  
node server.js
``` 

2. Open `index.html` in your browser

You should see a flower. If not, your browser probably doesn't support binary websockets.

Server code is contained in `server.js`
Client side code is contained in `index.html`